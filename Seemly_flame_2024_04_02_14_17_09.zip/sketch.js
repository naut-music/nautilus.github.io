function setup() {
  song = loadSound('assets/lucky_dragons_-_power_melody.mp3');

  createCanvas(400, 400);
}

function draw() {
  background(220);
}